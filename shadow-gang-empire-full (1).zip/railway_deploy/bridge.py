"""
Shadow Gang Empire — Local MT5 Bridge
=======================================
This runs on YOUR PC with MT5 open.
It reads your live account data and pushes
it to your Railway cloud server every 3 seconds.
It also receives trade commands from the cloud
and executes them in your MT5.

HOW IT WORKS:
  Your Browser → Railway Cloud ← This Bridge ← MT5
                      ↓
              Dashboard updates live

SETUP:
  1. Deploy app.py to Railway first (get your URL)
  2. Put your Railway URL in RAILWAY_URL below
  3. Run: python bridge.py
  4. Keep it running while MT5 is open
"""

import time, requests, threading
from datetime import datetime, timedelta

# ── CONFIG — UPDATE THESE ─────────────────────────────────────────────────
RAILWAY_URL   = "https://YOUR-APP-NAME.railway.app"   # ← paste your Railway URL here
BRIDGE_SECRET = "shadowgang2024"                        # must match Railway env variable
PUSH_INTERVAL = 3    # seconds between data pushes
SCAN_INTERVAL = 60   # seconds between strategy scans

# SMC Strategy settings
RISK_PCT       = 0.02
MIN_RR         = 3.0
MAX_TRADES_DAY = 5
PAIRS          = ['XAUUSD', 'EURUSD', 'GBPUSD', 'USDJPY']
SESSIONS       = {'london': (7,16), 'new_york': (13,22)}

# ── STATE ─────────────────────────────────────────────────────────────────
trades_today = 0
daily_pnl    = 0.0
daily_locked = False
last_balance = None

# ── MT5 INIT ──────────────────────────────────────────────────────────────
try:
    import MetaTrader5 as mt5
    MT5_OK = True
except ImportError:
    MT5_OK = False
    print("[!!] MetaTrader5 not found. Run: pip install MetaTrader5")

def init_mt5():
    if not MT5_OK:
        return False
    if not mt5.initialize():
        print(f"[!!] MT5 init failed: {mt5.last_error()}")
        return False
    info = mt5.account_info()
    if info is None:
        print("[!!] No account — make sure MT5 is open and logged in")
        return False
    print(f"[OK] MT5 connected: {info.login} | {info.server} | ${info.balance}")
    return True

# ── HELPERS ───────────────────────────────────────────────────────────────
HEADERS = {"X-Secret": BRIDGE_SECRET, "Content-Type": "application/json"}

def push(data):
    try:
        requests.post(f"{RAILWAY_URL}/bridge/push", json=data, headers=HEADERS, timeout=5)
    except Exception as e:
        print(f"[!!] Push failed: {e}")

def log_remote(type_, msg):
    try:
        requests.post(f"{RAILWAY_URL}/bridge/log", json={"type":type_,"msg":msg}, headers=HEADERS, timeout=3)
    except:
        pass
    print(f"[{type_.upper()}] {msg}")

def get_pending():
    try:
        r = requests.get(f"{RAILWAY_URL}/bridge/pending", headers=HEADERS, timeout=3)
        return r.json()
    except:
        return []

def get_pending_closes():
    try:
        r = requests.get(f"{RAILWAY_URL}/bridge/pending_closes", headers=HEADERS, timeout=3)
        return r.json()
    except:
        return []

def in_session():
    h = datetime.utcnow().hour
    for name,(s,e) in SESSIONS.items():
        if s <= h < e:
            return True, name
    return False, "asian"

# ── DATA PUSH LOOP ────────────────────────────────────────────────────────
def data_loop():
    global daily_pnl, last_balance
    print("[..] Data push loop started")
    while True:
        try:
            if MT5_OK:
                info = mt5.account_info()
                pos  = mt5.positions_get() or []
                if info:
                    fp = sum(p.profit for p in pos)
                    acc = {
                        "login":      info.login,
                        "server":     info.server,
                        "balance":    round(info.balance,2),
                        "equity":     round(info.equity,2),
                        "margin":     round(info.margin,2),
                        "free_margin":round(info.margin_free,2),
                        "float":      round(fp,2),
                        "currency":   info.currency,
                        "leverage":   info.leverage,
                    }
                    trades = [{
                        "id":      p.ticket,
                        "symbol":  p.symbol,
                        "type":    "BUY" if p.type==0 else "SELL",
                        "volume":  p.volume,
                        "price":   round(p.price_open,5),
                        "current": round(p.price_current,5),
                        "sl":      round(p.sl,5) if p.sl else None,
                        "tp":      round(p.tp,5) if p.tp else None,
                        "profit":  round(p.profit,2),
                    } for p in pos]

                    # Track daily PnL
                    if last_balance is None:
                        last_balance = info.balance
                    daily_pnl = round(info.balance - last_balance + fp, 2)

                    push({
                        "account":      acc,
                        "trades":       trades,
                        "daily_pnl":    daily_pnl,
                        "trades_today": trades_today,
                        "balance":      info.balance,
                    })

            # Check for pending trade commands from dashboard
            pending = get_pending()
            for trade in pending:
                result = execute_trade(trade)
                log_remote("bull" if result.get("ok") else "bear",
                    f"Trade {'executed' if result.get('ok') else 'failed'}: {trade.get('direction')} {trade.get('symbol')} — {result.get('error','')}")

            # Check for pending closes
            closes = get_pending_closes()
            for ticket in closes:
                result = close_trade(ticket)
                log_remote("info", f"Close #{ticket}: {'OK' if result.get('ok') else result.get('error')}")

        except Exception as e:
            print(f"[!!] Data loop error: {e}")

        time.sleep(PUSH_INTERVAL)

# ── STRATEGY SCANNER ──────────────────────────────────────────────────────
def scan_loop():
    global trades_today, daily_locked
    print("[..] Strategy scanner started")
    while True:
        time.sleep(SCAN_INTERVAL)
        if not MT5_OK or daily_locked:
            continue
        try:
            session_ok, session = in_session()
            if not session_ok:
                continue
            info = mt5.account_info()
            if not info or info.balance <= 0:
                continue

            # Daily loss check
            fp = sum(p.profit for p in (mt5.positions_get() or []))
            if fp < -(info.balance * 0.06):
                if not daily_locked:
                    daily_locked = True
                    log_remote("warn", "⚠ Daily loss limit hit — trading locked for today")
                continue

            # Reset at midnight
            if datetime.utcnow().hour == 0 and datetime.utcnow().minute < 2:
                trades_today = 0
                daily_locked = False

            signals = []
            for pair in PAIRS:
                if trades_today >= MAX_TRADES_DAY:
                    break
                sig = scan_smc(pair, info.balance)
                if sig:
                    signals.append(sig)
                    if sig.get("status") == "signal" and sig.get("confidence",0) >= 75:
                        result = execute_trade(sig)
                        if result.get("ok"):
                            trades_today += 1
                            log_remote("bull", f"🙏 AUTO-TRADE: {sig['direction']} {pair} @ {sig['entry']} | Conf:{sig['confidence']}%")

            # Push signals to cloud
            push({"signals": signals})

        except Exception as e:
            print(f"[!!] Scan error: {e}")

def scan_smc(symbol, balance):
    """Simplified SMC scan using MT5 data."""
    try:
        rates_h4 = mt5.copy_rates_from_pos(symbol, mt5.TIMEFRAME_H4, 0, 50)
        rates_h1 = mt5.copy_rates_from_pos(symbol, mt5.TIMEFRAME_H1, 0, 50)
        if rates_h4 is None or rates_h1 is None:
            return None

        price = float(rates_h1[-1]['close'])

        # HTF bias: is H4 making higher highs?
        h4_highs = [float(c['high']) for c in rates_h4[-10:]]
        h4_lows  = [float(c['low'])  for c in rates_h4[-10:]]
        bias = "bullish" if h4_highs[-1] > h4_highs[-3] else "bearish"

        # Find OB: last opposite candle before impulse
        ob_high = ob_low = None
        for i in range(3, 15):
            idx = len(rates_h1)-1-i
            c   = rates_h1[idx]
            nxt = rates_h1[idx+1]
            if bias=="bullish" and c['close']<c['open'] and nxt['close']>c['high']:
                ob_high = float(c['high']); ob_low = float(c['low']); break
            if bias=="bearish" and c['close']>c['open'] and nxt['close']<c['low']:
                ob_high = float(c['high']); ob_low = float(c['low']); break

        if ob_high is None:
            return {"symbol":symbol,"status":"watching","bias":bias,"price":round(price,5)}

        # Check if price is at OB
        at_ob = ob_low <= price <= ob_high*1.001 if bias=="bullish" else ob_low*0.999 <= price <= ob_high

        if not at_ob:
            return {"symbol":symbol,"status":"watching","bias":bias,"price":round(price,5)}

        # Calculate SL/TP
        if bias=="bullish":
            sl   = round(ob_low*0.9995, 5)
            tp   = round(price + (price-sl)*MIN_RR, 5)
            direction = "BUY"
        else:
            sl   = round(ob_high*1.0005, 5)
            tp   = round(price - (sl-price)*MIN_RR, 5)
            direction = "SELL"

        sl_pips = round(abs(price-sl)*10000, 1)
        rr      = round(abs(tp-price)/max(abs(price-sl),0.0001), 2)

        if rr < MIN_RR:
            return {"symbol":symbol,"status":"watching","bias":bias,"price":round(price,5)}

        conf = 65
        # FVG bonus
        for i in range(1,10):
            idx=len(rates_h1)-1-i
            if idx>0:
                prev=rates_h1[idx-1]; nxt=rates_h1[idx+1]
                if bias=="bullish" and prev['high']<nxt['low']: conf+=10; break
                if bias=="bearish" and prev['low']>nxt['high']: conf+=10; break
        # BOS bonus
        swing_high = max(float(c['high']) for c in rates_h1[-20:-1])
        swing_low  = min(float(c['low'])  for c in rates_h1[-20:-1])
        if (bias=="bullish" and price>swing_high) or (bias=="bearish" and price<swing_low):
            conf += 10

        return {
            "symbol":     symbol,
            "direction":  direction,
            "entry":      round(price,5),
            "sl":         sl,
            "tp":         tp,
            "sl_pips":    sl_pips,
            "rr":         rr,
            "confidence": min(conf,95),
            "status":     "signal",
            "session":    in_session()[1],
            "confluence": ["OB","FVG","BOS"][:max(1,conf//25)],
        }
    except Exception as e:
        return {"symbol":symbol,"status":"error","error":str(e)}

# ── TRADE EXECUTION ───────────────────────────────────────────────────────
def execute_trade(signal):
    global trades_today
    if not MT5_OK:
        return {"ok":False,"error":"MT5 not available"}
    try:
        sym  = signal['symbol']
        bal  = mt5.account_info().balance
        risk = bal * RISK_PCT
        sl_p = signal.get('sl_pips', 30)
        lot  = max(0.01, min(0.10, round(risk/(sl_p*1.0), 2)))

        info = mt5.symbol_info(sym)
        if not info: return {"ok":False,"error":f"Symbol {sym} not found"}
        if not info.visible: mt5.symbol_select(sym, True)

        tick = mt5.symbol_info_tick(sym)
        if not tick: return {"ok":False,"error":"No tick"}

        is_buy = signal['direction']=='BUY'
        req = {
            "action":       mt5.TRADE_ACTION_DEAL,
            "symbol":       sym,
            "volume":       lot,
            "type":         mt5.ORDER_TYPE_BUY if is_buy else mt5.ORDER_TYPE_SELL,
            "price":        tick.ask if is_buy else tick.bid,
            "sl":           float(signal['sl']),
            "tp":           float(signal['tp']),
            "deviation":    20,
            "magic":        20240101,
            "comment":      "ShadowGang",
            "type_time":    mt5.ORDER_TIME_GTC,
            "type_filling": mt5.ORDER_FILLING_IOC,
        }
        r = mt5.order_send(req)
        if r.retcode != mt5.TRADE_RETCODE_DONE:
            return {"ok":False,"error":f"Code {r.retcode}: {r.comment}"}
        return {"ok":True,"ticket":r.order,"lot":lot}
    except Exception as e:
        return {"ok":False,"error":str(e)}

def close_trade(ticket):
    if not MT5_OK: return {"ok":False,"error":"No MT5"}
    try:
        pos = mt5.positions_get(ticket=int(ticket))
        if not pos: return {"ok":False,"error":"Not found"}
        p    = pos[0]
        tick = mt5.symbol_info_tick(p.symbol)
        req  = {
            "action":       mt5.TRADE_ACTION_DEAL,
            "symbol":       p.symbol,
            "volume":       p.volume,
            "type":         mt5.ORDER_TYPE_SELL if p.type==0 else mt5.ORDER_TYPE_BUY,
            "position":     int(ticket),
            "price":        tick.bid if p.type==0 else tick.ask,
            "deviation":    20,
            "magic":        20240101,
            "comment":      "ShadowGang_Close",
            "type_time":    mt5.ORDER_TIME_GTC,
            "type_filling": mt5.ORDER_FILLING_IOC,
        }
        r = mt5.order_send(req)
        return {"ok": r.retcode==mt5.TRADE_RETCODE_DONE, "error": r.comment}
    except Exception as e:
        return {"ok":False,"error":str(e)}

# ── MAIN ──────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("=" * 50)
    print("  🙏 Shadow Gang Empire — MT5 Bridge")
    print("=" * 50)
    print(f"[..] Connecting to Railway: {RAILWAY_URL}")

    if RAILWAY_URL == "https://YOUR-APP-NAME.railway.app":
        print("[!!] UPDATE RAILWAY_URL in this file first!")
        print("     Open bridge.py in Notepad and paste your Railway URL")
        input("Press Enter to exit...")
        exit()

    if MT5_OK:
        if not init_mt5():
            print("[!!] MT5 not ready. Open MT5 and log in, then restart bridge.")
            input("Press Enter to exit...")
            exit()
    else:
        print("[!!] MetaTrader5 library missing — run: pip install MetaTrader5")
        input("Press Enter...")
        exit()

    # Test cloud connection
    try:
        r = requests.get(f"{RAILWAY_URL}/ping", timeout=5)
        print(f"[OK] Railway server reachable!")
    except:
        print(f"[!!] Cannot reach Railway server. Check your URL.")
        input("Press Enter to exit...")
        exit()

    # Start threads
    threading.Thread(target=data_loop,  daemon=True).start()
    threading.Thread(target=scan_loop,  daemon=True).start()

    log_remote("info", "MT5 Bridge connected 🙏 — pushing live data to cloud")

    print("[OK] Bridge running — pushing data to cloud every 3s")
    print("[OK] Strategy scanner active — checking every 60s")
    print("[..] Keep this window open. Press CTRL+C to stop.")
    print("=" * 50)

    # Keep alive
    while True:
        time.sleep(10)
        print(f"[..] {datetime.now().strftime('%H:%M:%S')} — Bridge alive | Trades today: {trades_today}")
