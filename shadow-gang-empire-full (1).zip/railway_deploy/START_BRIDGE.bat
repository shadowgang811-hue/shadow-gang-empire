@echo off
title Shadow Gang — MT5 Bridge
color 0A
echo.
echo  ==========================================
echo   🙏 Shadow Gang Empire — MT5 Bridge
echo  ==========================================
echo.
echo  Make sure MetaTrader 5 is open and
echo  logged into Exness-Real9 before continuing!
echo.
echo  Starting bridge in 3 seconds...
timeout /t 3 /nobreak >nul
python "%~dp0bridge.py"
pause
