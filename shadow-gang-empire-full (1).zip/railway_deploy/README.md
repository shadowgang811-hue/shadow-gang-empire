# 🙏 Shadow Gang Empire — Deployment Guide

## HOW IT WORKS
```
Your Browser (anywhere) 
      ↕
Railway Cloud Server (24/7 free) ← app.py
      ↕
Your PC bridge.py ← MetaTrader5 (MT5)
```

---

## STEP 1 — Upload to GitHub

1. Go to https://github.com
2. Click the "+" button top right → "New repository"
3. Name it: `shadow-gang-empire`
4. Set to **Public**
5. Click "Create repository"
6. Click "uploading an existing file"
7. Drag and drop ONLY these 3 files:
   - `app.py`
   - `requirements.txt`
   - `Procfile`
8. Click "Commit changes"

---

## STEP 2 — Deploy to Railway

1. Go to https://railway.app
2. Click "Login with GitHub"
3. Authorize Railway
4. Click "New Project"
5. Click "Deploy from GitHub repo"
6. Select `shadow-gang-empire`
7. Railway auto-deploys! Wait ~2 minutes.
8. Click your project → "Settings" → "Domains"
9. Click "Generate Domain"
10. Copy your URL (looks like: https://shadow-gang-empire-xxx.railway.app)

---

## STEP 3 — Update your bridge.py

1. Open `bridge.py` in Notepad
2. Find this line:
   `RAILWAY_URL = "https://YOUR-APP-NAME.railway.app"`
3. Replace with your actual Railway URL
4. Save the file

---

## STEP 4 — Update your dashboard

1. Open `shadow-gang-empire.html` in Notepad
2. Press Ctrl+H (Find & Replace)
3. Find:    `http://localhost:5000`
4. Replace: your Railway URL (e.g. https://shadow-gang-empire-xxx.railway.app)
5. Save

---

## STEP 5 — Run daily (on your PC)

1. Open MetaTrader 5 and log into Exness-Real9
2. Double-click `START_BRIDGE.bat`
3. Open `shadow-gang-empire.html` in your browser
4. Log in and monitor!

The Railway server runs 24/7 even when your PC is off.
When your PC is on and bridge.py is running, live data flows.
When your PC is off, the dashboard shows last known data.

---

## FILES
- `app.py`          → runs on Railway cloud (24/7)
- `bridge.py`       → runs on your PC (connects MT5 to cloud)
- `requirements.txt`→ Python packages for Railway
- `Procfile`        → tells Railway how to start
